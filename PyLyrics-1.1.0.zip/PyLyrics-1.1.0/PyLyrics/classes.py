#Classes for Scrapers
try:
	from .functions import *
except:
	from functions import *

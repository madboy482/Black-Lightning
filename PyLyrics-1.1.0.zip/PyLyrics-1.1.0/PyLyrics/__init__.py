__author__ = "Pradipta"
__version__ = '1.0.0'

try:
	#Python 3 Imports
	from .classes import *
	from .functions import *
except:
	#Python 2 imports
	from classes import *
	from functions import *


	
Changes
=======

1.0.3 (2016-05-15)
------------------

* Python 3 fixes.


1.0.2 (2011-10-20)
------------------

* Fixed setup.py from failing upon not seeing README.rst when installing using
  easy_install.


1.0.1 (2011-10-10)
------------------

* Fixed setup.py package not including a MANIFEST.in


1.0 (2011-10-03)
----------------

* Published decoupled code from SocialGrapple.

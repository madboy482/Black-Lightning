History
=======

3.4.0
-----
* Support for python 2.6 dropped
* Add Tests
* Get project building on circleci/travis-ci & coveralls
* Adding Slug to Release Models
* bugfixes

3.2.0-2
-------
* Various fixes for python3
* Add newer features from Heroku API, support for Organisations

3.1.4
-----
* bugfixes

3.1.3 (2015-03-12)
------------------
* removed debug

3.1.0 (2014-11-24)
------------------
* Moved to Heroku3 for pypi release
* Updated heroku/data/cacert.pem

3.0.0 - 3.1.0
-------------
* Add support for all of heroku's api
* Various bugfixes and enhancements
* Add Documentation
* Add examples.py
* Used in production on https://www.migreat.com & https://www.migreat.co.uk since 2013-10-01

3.0.0 (2013-08-28)
------------------
* Rewrite to support V3 API

* Initial release.

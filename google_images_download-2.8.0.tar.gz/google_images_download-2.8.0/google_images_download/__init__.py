#!/usr/bin/env python
from __future__ import absolute_import


def main():
    import google_images_download.google_images_download

if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
__author__ = 'Thomas Eberle'


class Base:
    def __init__(self):
        pass

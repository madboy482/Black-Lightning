# -*- coding: utf-8 -*-
__author__ = 'Thomas Eberle'


class Sticker:
    def __init__(self, file_id, width, height, thumb, file_size):
        self.file_id = file_id
        self.width = width
        self.height = height
        self.thumb = thumb
        self.file_size = file_size

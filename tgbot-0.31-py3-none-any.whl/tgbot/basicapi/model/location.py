# -*- coding: utf-8 -*-
__author__ = 'Thomas Eberle'


class Location:
    def __init__(self, longitude, latitude):
        self.longitude = longitude
        self.latitude = latitude

# -*- coding: utf-8 -*-
__author__ = 'Thomas'

def parsetext(message):
   pass

# -*- coding: utf-8 -*-
__author__ = 'Thomas Eberle'

blue_diamond = "\U0001F539"
info_button = "\U00002139"
thumb_down = "\U0001F44E"
check_mark = "\U00002705"
cross_mark = "\U0000274E"
watch = "\U000023F0"
headphone = "\U0001F3A7"
alarm_clock = "\U000023F0"
loudspeaker = "\U0001F4E2"
microphone = "\U0001F3A4"
satellite = "\U0001F4E1"
musical_note = "\U0001F3B6"
warning = "\U000026A0"


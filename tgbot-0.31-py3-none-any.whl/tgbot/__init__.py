__author__ = 'Tommy'

iniconfig = None

mainmessage = None
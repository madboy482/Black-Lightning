This is a standalone package providing the uwsgidecorators Python module.
Please refer to http://uwsgi-docs.readthedocs.org/en/latest/PythonDecorators.html in order to get further documentation.
